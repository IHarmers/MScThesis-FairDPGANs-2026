# -*- coding: utf-8 -*-
"""
Created on Fri May 30 17:35:37 2025

@author: ilseh
"""

from snsynth.transform.definitions import ColumnType
from .base import ColumnTransformer
import numpy as np

class LogModulusTransformer(ColumnTransformer):
    """Logarithmic modulus transformation of values, including negative values. Useful for transforming skewed data.

    """
    def __init__(self):
        super().__init__()
    @property
    def output_type(self):
        return ColumnType.CONTINUOUS
    @property
    def cardinality(self):
        return [None]
    def _fit(self, val, idx=None):
        pass
    def _clear_fit(self):
        # this transform doesn't need fit
        self._fit_complete = True
        self.output_width = 1
    def _transform(self, val):
        if val is None or (isinstance(val, float) and np.isnan(val)):
            return None
        elif val < 0:
            return float(-1 * np.log(abs(val) + 1))
        elif val >= 0:
            return float(np.log(val + 1))
    def _inverse_transform(self, val):
        if val is None or (isinstance(val, float) and np.isnan(val)):
            return np.nan
        elif val < 0:
            return float(-1 * (np.exp(abs(val)) - 1))
        elif val >= 0:
            return float(np.exp(val) - 1)