# -*- coding: utf-8 -*-
"""
Created on Tue Sep 30 10:14:56 2025

@author: ilseh
"""

import pandas as pd
import numpy as np
import snsynth.transform as tf
from snsynth import Synthesizer
from utils import one_hot_encode

# Initializing the synthesizer for preprocessing the datasets with the TableTransformer function. 
synth = Synthesizer.create('pategan', epsilon = 10.0, delta = 1e-05, plot_losses = True)

def encode_adult(sample):
    """This function encodes an Adult-based synthetic dataset such that all categorical columns are (one-hot) 
    encoded and all numerical columns are scaled to a range of (0, 1).
    
    sample [pandas DataFrame]: synthetic dataset
    """
    
    # One-hot encoding an Adult-based dataset. 
    cat_columns = sample.select_dtypes(include=['object']).columns.to_list()
    sample_cat_encoded = one_hot_encode(sample[cat_columns], order = [[" <=50K", " >50K"], [" Female", " Male"]])

    # Transforming the continuous columns with the TableTransformer function.
    tt = tf.TableTransformer([  
        tf.MinMaxTransformer(lower = sample["age"].min(), upper = sample["age"].max(),
                             negative = False), # age; scaling to range (0, 1)
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["capital-gain"].max() + 1),
                                 negative = False) # capital-gain; scaling to range (0, 1)
            ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["capital-loss"].max() + 1),
                                 negative = False) # capital-loss; scaling to range (0, 1)
            ]),
        tf.MinMaxTransformer(lower = sample["hours-per-week"].min(), 
                             upper = sample["hours-per-week"].max(), negative = False), # hours-per-week; scaling to range (0, 1)
        ])

    tf_cont_cols = np.array(synth._get_train_data(
                        sample[["age", "capital-gain", "capital-loss", "hours-per-week"]], transformer = tt, 
                        preprocessor_eps = 0.0, style = 'gan', nullable = False, categorical_columns = None, 
                        ordinal_columns = None, continuous_columns = None,))

    num_encoded = pd.DataFrame(tf_cont_cols, columns = ["age", "capital-gain", "capital-loss", "hours-per-week"])
    
    # Concatenating all the columns back together.
    sample_encoded = pd.concat([sample_cat_encoded.reset_index(drop = True), num_encoded.reset_index(drop = True), 
                           sample[["education-num"]].reset_index(drop = True)], axis = 1)
    
    return sample_encoded

def encode_credit(sample):
    """This function encodes a Credit-based synthetic dataset such that all categorical columns are (one-hot) 
    encoded and all numerical columns are scaled to a range of (0, 1).
    
    sample [pandas DataFrame]: synthetic dataset
    """
    
    # One-hot encoding the "EDUCATION" and "MARRIAGE" columns in the Credit-based dataset. 
    cat_columns = sample.select_dtypes(include=['object']).columns.to_list()
    sample_cat_encoded = one_hot_encode(sample[cat_columns].astype(str))
    
    # Transforming the continuous columns with the TableTransformer function.
    tt = tf.TableTransformer([
        tf.ChainTransformer([
            tf.LogTransformer(),
            tf.MinMaxTransformer(lower = np.log(sample["LIMIT_BAL"].min()), upper = np.log(sample["LIMIT_BAL"].max()),
                                 negative = False) # LIMIT_BAL; scaling to range (0, 1)
        ]),
        tf.MinMaxTransformer(lower = sample["AGE"].min(), upper = sample["AGE"].max(), negative = False), # AGE; scaling to range (0, 1)
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["BILL_AMT1"].min()) + 1)), upper = np.log(sample["BILL_AMT1"].max() + 1), 
                                 negative = False) # BILL_AMT1; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["BILL_AMT2"].min()) + 1)), upper = np.log(sample["BILL_AMT2"].max() + 1), 
                                 negative = False) # BILL_AMT2; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["BILL_AMT3"].min()) + 1)), upper = np.log(sample["BILL_AMT3"].max() + 1),
                                 negative = False) # BILL_AMT3; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["BILL_AMT4"].min()) + 1)), upper = np.log(sample["BILL_AMT4"].max() + 1), 
                                    negative = False) # BILL_AMT4; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["BILL_AMT5"].min()) + 1)), upper = np.log(sample["BILL_AMT5"].max() + 1),
                                 negative = False) # BILL_AMT5; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["BILL_AMT6"].min()) + 1)), upper = np.log(sample["BILL_AMT6"].max() + 1), 
                                 negative = False) # BILL_AMT6; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["PAY_AMT1"].max() + 1), 
                                 negative = False) # PAY_AMT1; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["PAY_AMT2"].max() + 1), 
                                 negative = False) # PAY_AMT2; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["PAY_AMT3"].max() + 1), 
                                 negative = False) # PAY_AMT3; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["PAY_AMT4"].max() + 1), 
                                 negative = False) # PAY_AMT4; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["PAY_AMT5"].max() + 1), 
                                 negative = False) # PAY_AMT5; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["PAY_AMT6"].max() + 1), 
                                 negative = False) # PAY_AMT6; scaling to range (0, 1)
        ]),
        ])

    tf_cont_cols = np.array(synth._get_train_data(
        sample[['LIMIT_BAL', 'AGE', 'BILL_AMT1', 'BILL_AMT2', 'BILL_AMT3', 'BILL_AMT4', 'BILL_AMT5', 
                'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2', 'PAY_AMT3', 'PAY_AMT4','PAY_AMT5', 'PAY_AMT6']],
        transformer = tt, preprocessor_eps = 0.0, style = 'gan', nullable = False, categorical_columns=None,
        ordinal_columns=None, continuous_columns=None,))

    num_encoded = pd.DataFrame(tf_cont_cols, columns = ['LIMIT_BAL', 'AGE', 'BILL_AMT1', 'BILL_AMT2','BILL_AMT3', 
                                                        'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1', 'PAY_AMT2', 
                                                        'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6'])

    # Concatenating all the columns back together.
    sample_encoded = pd.concat([num_encoded.reset_index(drop = True), sample_cat_encoded.reset_index(drop = True),
                        sample[['SEX', 'PAY_0', 'PAY_2', 'PAY_3', 'PAY_4', 'PAY_5', 'PAY_6', 'DEFAULT']].reset_index(drop = True)], axis = 1)
    
    return sample_encoded

def encode_bank(sample):
    """This function encodes a Bank-based synthetic dataset such that all categorical columns are (one-hot) 
    encoded and all numerical columns are scaled to a range of (0, 1).
    
    sample [pandas DataFrame]: synthetic dataset
    """
    
    # One-hot encoding a Bank-based dataset. 
    cat_columns = sample.select_dtypes(include=['object']).columns.to_list()
    sample_cat_encoded = one_hot_encode(sample[cat_columns], order = [["no", "yes"]])
    
    # Transforming the continuous columns with the TableTransformer function.
    tt = tf.TableTransformer([
        tf.MinMaxTransformer(lower = sample["age"].min(), upper = sample["age"].max(),
                                negative = False), # age; scaling to range (0, 1)
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["balance"].min()) + 1)),
                                 upper = np.log(sample["balance"].max() + 1), 
                                 negative = False) # balance; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["duration"].max() + 1), 
                                 negative = False) # duration; scaling to range (0, 1)
        ]),
        tf.MinMaxTransformer(lower = sample["campaign"].min(), upper = sample["campaign"].max(),
                             negative = False), # campaign; scaling to range (0, 1)
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = -1 * (np.log(abs(sample["pdays"].min()) + 1)), 
                                 upper = np.log(sample["pdays"].max() + 1),
                                 negative = False) # pdays; scaling to range (0, 1)
        ]),
        tf.ChainTransformer([
            tf.LogModulusTransformer(),
            tf.MinMaxTransformer(lower = 0, upper = np.log(sample["previous"].max() + 1),
                        negative = False) # previous; scaling to range (0, 1)
        ]),
    ])

    tf_cont_cols = np.array(synth._get_train_data(
                sample[["age", "balance", "duration", "campaign", "pdays", "previous"]], transformer = tt, 
                preprocessor_eps = 0.0, style = 'gan', nullable = False, categorical_columns=None, 
                ordinal_columns=None, continuous_columns=None,))

    num_encoded = pd.DataFrame(tf_cont_cols, columns = ["age", "balance", "duration", "campaign", "pdays", "previous"])

    # Concatenating all the columns back together.
    sample_encoded = pd.concat([num_encoded.reset_index(drop = True), sample_cat_encoded.reset_index(drop = True), 
                                sample[["day"]].reset_index(drop = True)], axis = 1)
    
    return sample_encoded

def missing_cols_insert(df1, df2):
    """This function inserts 'missing' columns into df2, if there are certain columns present in df1 but not in df2. 
    
    df1 [pandas DataFrame]: synthetic dataset
    df2 [pandas DataFrame]: synthetic dataset
    """
    
    # Checking for missing columns between df1 and df2. 
    missing_columns = list(set(list(df1.columns)) - set(list(df2.columns)))
    # If there is a missing column, most likely due to a label from df1 not being present in df2, then 
    # we reinsert a 'zero' column into df2 at the right place to account for this missing label.
    if missing_columns:
        for c in missing_columns:
            df_col = pd.DataFrame({c: pd.Series(np.zeros(df2.shape[0]))})
            df2.insert(0, c, value = df_col)
    df2 = df2[df1.columns]   # df1 & df2 should have same ordering of columns