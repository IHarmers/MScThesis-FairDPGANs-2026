import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import snsynth.pytorch.nn.transform_utils as tu
import snsynth.pytorch.nn.utils as utils

import torch
import torch.nn as nn
import torch.optim as optim

from torch.utils.data import DataLoader, TensorDataset

from opacus import PrivacyEngine

from snsynth.base import Synthesizer

from ._generator import Generator
from ._discriminator import Discriminator

import time

class FairDPGAN(Synthesizer):
    def __init__(
        self,
        s,   # name of sensitive column in real dataset
        s_unpriv,   # label of unprivileged group in sensitive column
        s_priv,   # label of privileged group in sensitive column
        y,   # name of target column in real dataset
        y_des,   # name of positive class label in target column
        binary=False,
        latent_dim=64,
        batch_size=64,
        epochs=1000,
        delta=None,
        epsilon=1.0,
        lamda = 0.5,   # impact of fairness loss in total generator loss
        fair_loss = "dem",   # dataset or classifier fairness loss: ["dem", "dis", "dem-dis", "clf_dem", "clf_dis", "clf_eqopp", "clf_all"]
        dis_offset = 1.0,   # offset in disparate impact loss
        beta1 = 0.9,
        dataset = None,
        plot_losses = False,   # Boolean argument: if True, losses of the generator and discriminator will be plotted
        file_path = None,  # loss plots will be saved at this filepath
        sanity_check = False,   # Boolean argument: if True, print some checks on the workings of the fairness loss
        epoch_time = False   # Boolean argument: if True, average time per epoch will be returned
    ):
        self.binary = binary
        self.latent_dim = latent_dim
        self.batch_size = batch_size
        self.epochs = epochs
        self.delta = delta
        self.epsilon = epsilon
        self.beta1 = beta1
        self.dataset = dataset
        self.plot_losses = plot_losses
        self.file_path = file_path
        self.sanity_check = sanity_check
        self.epoch_time = epoch_time
        
        self.s = s   
        self.s_unpriv = s_unpriv
        self.s_priv = s_priv
        self.y = y
        self.y_des = y_des
        self.lamda = lamda
        self.fair_loss = fair_loss
        self.dis_offset = dis_offset

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

        self.pd_cols = None
        self.pd_index = None


    def data_fair_loss(self, data, s, s_unpriv, s_priv, y, y_des, lamda, 
                       data_loss, s_labs = None, y_labs = None, transform = True):
        """This function computes the inputted dataset fairness loss based on the data.
        
        data [array-like]: dataset or batch of data 
        s [string]: sensitive column name
        s_unpriv [string]: unprivileged group name
        s_priv [string]: privileged group name
        y [string]: target column name
        y_des [string]: positive target label 
        lamda [float]: value of lambda parameter in fairness loss
        data_loss [string]: name of dataset fairness loss; can be set to "dem", "dis" or "dem-dis"
        s_labs [dictionary]: original sensitive groups in real dataset; needed for transforming
        y_labs [dictionary]: original target classes in real dataset; needed for transforming
        transform [Boolean]: Boolean argument: if True, inputted data is transformed to original format
        """
        
        # Transforming the input data's sensitive and target columns back to the column's original/real values. 
        if transform:
            if self.dataset != "Bank":
                s_col = pd.Series(np.argmax(data.detach().cpu().numpy()[:, [0, 1]], axis = 1)).replace(s_labs)
                y_col = pd.Series(np.argmax(data.detach().cpu().numpy()[:, [2, 3]], axis = 1)).replace(y_labs)
                df = pd.concat([s_col.reset_index(drop = True), y_col.reset_index(drop = True)], 
                               axis = 1).rename(columns = {0: s, 1: y})
            elif self.dataset == "Bank":
                s_col = pd.Series(np.clip(data.detach().cpu().numpy()[:, 0]*(s_labs["upper"] - s_labs["lower"]) + s_labs["lower"],
                                  s_labs["lower"], s_labs["upper"]))   # reversing min-max scaling
                y_col = pd.Series(np.argmax(data.detach().cpu().numpy()[:, [1, 2]], axis = 1)).replace(y_labs)
                df = pd.concat([s_col.reset_index(drop = True), y_col.reset_index(drop = True)], 
                               axis = 1).rename(columns = {0: s, 1: y})
            else:
                raise ValueError("Dataset not supported.")
        else:
            df = data
        
        if self.dataset == "Bank":
            S1 = df[s].loc[df[s] <= s_priv].shape[0]
            S0 = df[s].loc[df[s] > s_unpriv].shape[0]
            S1Y1 = df[[s, y]].loc[(df[s] <= s_priv) & (df[y] == y_des)].shape[0]
            S0Y1 = df[[s, y]].loc[(df[s] > s_unpriv) & (df[y] == y_des)].shape[0]
        else:
            S1 = df[s].loc[df[s] == s_priv].shape[0]
            S0 = df[s].loc[df[s] == s_unpriv].shape[0]
            S1Y1 = df[[s, y]].loc[(df[s] == s_priv) & (df[y] == y_des)].shape[0]
            S0Y1 = df[[s, y]].loc[(df[s] == s_unpriv) & (df[y] == y_des)].shape[0]
            
        if self.sanity_check:
            print("S1:", S1)
            print("S0:", S0)
            print("S1Y1:", S1Y1)
            print("S0Y1:", S0Y1)
        
        if data_loss == "dem":
            # Demographic parity.
            try:
                loss = lamda * ((S1Y1/S1) - (S0Y1/S0))
            except ZeroDivisionError:
                if S0 == 0:
                    loss = lamda * ((S1Y1/S1))
                else:
                    loss = lamda * (-1 * (S0Y1/S0))
            return abs(loss)
        elif data_loss == "dis":
            # Disparate impact.
            try:
                loss = lamda * (((S0Y1*S1)/(S0*S1Y1)) - self.dis_offset)
            except ZeroDivisionError:
                loss = lamda * (-1 * self.dis_offset)
                
            return abs(loss)
        elif data_loss == "dem-dis":
            # Demographic parity.
            try:
                loss1 = lamda * ((S1Y1/S1) - (S0Y1/S0))
            except ZeroDivisionError:
                if S0 == 0:
                    loss1 = lamda * ((S1Y1/S1))
                else:
                    loss1 = lamda * (-1 * (S0Y1/S0))
            
            # Disparate impact.
            try:
                loss2 = lamda * (((S0Y1*S1)/(S0*S1Y1)) - self.dis_offset)
            except ZeroDivisionError:
                loss2 = lamda * (-1 * self.dis_offset)
                
            # Demographic parity + disparate impact.
            return abs(loss1) + abs(loss2)
        else:
            raise ValueError("Loss function not supported.")
    
    def clf_fair_loss(self, data, s, s_unpriv, s_priv, y, y_des, lamda, clf_loss):
        """This function computes the inputted classifier fairness loss based on the data.
        
        TODO: remove y_des dependency (redundant)
        
        data [array-like]: dataset or batch of data 
        s [string]: sensitive column name
        s_unpriv [string]: unprivileged group name
        s_priv [string]: privileged group name
        y [string]: target column name
        y_des [string]: positive target label 
        lamda [float]: value of lambda parameter in fairness loss
        clf_loss [string]: name of classifier fairness loss; can be set to "dem", "dis", "eqopp" 
                           or "clf_all"
        """
        
        synth_data = self._transformer.inverse_transform(data.detach().cpu().numpy())
        train_set, test_set = train_test_split(synth_data, train_size = 0.80, random_state = 42)
        
        # Encoding the train and test sets. 
        if self.dataset == "Adult":
            train_encoded = tu.encode_adult(train_set)
            test_encoded = tu.encode_adult(test_set)
        elif self.dataset == "Bank":
            train_encoded = tu.encode_bank(train_set)
            test_encoded = tu.encode_bank(test_set)
        elif self.dataset == "Credit":
            train_encoded = tu.encode_credit(train_set)
            test_encoded = tu.encode_credit(test_set)
        else:
            raise ValueError("Dataset not supported.")
            
        # Ensuring that train and test sets have the same amount of columns.
        tu.missing_cols_insert(train_encoded, test_encoded)
        tu.missing_cols_insert(test_encoded, train_encoded)
        train_encoded = train_encoded[test_encoded.columns]   # train should have same ordering of columns as test
        
        # Training a random forest classifier and generating its predictions.
        clf = RandomForestClassifier(n_estimators = 10)
        model_synth = clf.fit(train_encoded.drop(columns = [y]), train_encoded[y])
        preds_synth = model_synth.predict(test_encoded.drop(columns = [y]))
        
        # Creating a DataFrame with the test set's sensitive column, encoded target column and 
        # the classifier's predictions.
        preds_synth = pd.Series(preds_synth, name = "preds")
        test_cols = pd.concat([test_set[[s]].reset_index(drop = True), 
                               test_encoded[[y]].reset_index(drop = True), 
                               preds_synth.reset_index(drop = True)],
                              axis = 1)
        
        if self.sanity_check:
            print(test_cols)
            test_cols_old = pd.concat([test_set[[s, y]].reset_index(drop = True), 
                                      preds_synth.reset_index(drop = True)],
                                      axis = 1)
            print(test_cols_old)
            if self.dataset == "Bank":
                print(test_cols.loc[test_cols[s] > s_unpriv].shape[0])
            else:
                print(test_cols.loc[test_cols[s] == s_unpriv].shape[0])
        
        if clf_loss == "dem":
            # Demographic parity.
            dem_clf = self.data_fair_loss(data = test_cols, s = s,
                                          s_unpriv = s_unpriv,
                                          s_priv = s_priv, y = "preds", 
                                          y_des = 1, lamda = lamda,
                                          data_loss = "dem", transform = False)
            if self.sanity_check:
                print(dem_clf)
            return dem_clf
        elif clf_loss == "dis":
            # Disparate impact.
            dis_clf = self.data_fair_loss(data = test_cols, s = s,
                                          s_unpriv = s_unpriv,
                                          s_priv = s_priv, y = "preds", 
                                          y_des = 1, lamda = lamda,
                                          data_loss = "dis", transform = False)
            if self.sanity_check:
                print(dis_clf)
            return dis_clf
        elif clf_loss == "eqopp":
            # Equal opportunity.
            eqopp_clf = utils.equal_opportunity(df = test_cols, s = s, y_true = y, y_pred = "preds",
                                                s_priv = s_priv, s_unpriv = s_unpriv, 
                                                sanity_check = self.sanity_check, 
                                                dataset = self.dataset)
            if self.sanity_check:
                print(eqopp_clf)
            return lamda*abs(eqopp_clf)
        elif clf_loss == "clf_all":
            # Demographic parity. 
            dem_clf = self.data_fair_loss(data = test_cols, s = s,
                                          s_unpriv = s_unpriv,
                                          s_priv = s_priv, y = "preds", 
                                          y_des = 1, lamda = lamda,
                                          data_loss = "dem", transform = False)
            # Disparate impact.
            dis_clf = self.data_fair_loss(data = test_cols, s = s,
                                          s_unpriv = s_unpriv,
                                          s_priv = s_priv, y = "preds", 
                                          y_des = 1, lamda = lamda,
                                          data_loss = "dis", transform = False)
            # Equal opportunity.
            eqopp_clf = utils.equal_opportunity(df = test_cols, s = s, y_true = y, y_pred = "preds",
                                                s_priv = s_priv, s_unpriv = s_unpriv,
                                                sanity_check = self.sanity_check,
                                                dataset = self.dataset)
            if self.sanity_check:
                print(dem_clf)
                print(dis_clf)
                print(eqopp_clf)
            
            # Demographic parity + disparate impact + equal opportunity.
            return dem_clf + dis_clf + lamda*abs(eqopp_clf)
        else:
            raise ValueError("Loss function not supported.")

    def train(
        self,
        data,
        categorical_columns=None,
        ordinal_columns=None,
        update_epsilon=None,
        transformer=None,
        continuous_columns=None,
        preprocessor_eps=0.0,
        nullable=False,
    ):
        if update_epsilon:
            self.epsilon = update_epsilon

        # Saving the column 'labels' for the sensitive and target attributes to speed up training time during
        # computation of the dataset fairness loss. 
        if self.dataset == "Adult":
            s_labs = {0: data[self.s].unique()[0], 1: data[self.s].unique()[1]}
            y_labs = {0: data[self.y].unique()[0], 1: data[self.y].unique()[1]}
        elif self.dataset == "Credit":
            s_labs = {0: 1, 1: 2}   # transformer will always order numerical labels
            y_labs = {0: data[self.y].unique()[0], 1: data[self.y].unique()[1]}
        elif self.dataset == "Bank":
            s_labs = {"lower": data[self.s].min(), "upper": data[self.s].max()}
            y_labs = {0: data[self.y].unique()[0], 1: data[self.y].unique()[1]}
        else:
            raise ValueError("Dataset not supported.")
        print(s_labs, y_labs)
        
        train_data = self._get_train_data(
            data,
            style='gan',
            transformer=transformer,
            categorical_columns=categorical_columns, 
            ordinal_columns=ordinal_columns, 
            continuous_columns=continuous_columns, 
            nullable=nullable,
            preprocessor_eps=preprocessor_eps
        )

        data = np.array(train_data)
        print("data.shape:", data.shape)
        print(self.device)

        if isinstance(data, pd.DataFrame):
            for col in data.columns:
                data[col] = pd.to_numeric(data[col], errors="ignore")
            self.pd_cols = data.columns
            self.pd_index = data.index
            data = data.to_numpy()
        elif isinstance(data, list):
            data = np.array(data)
        elif not isinstance(data, np.ndarray):
            raise ValueError("Data must be a numpy array or pandas dataframe")

        dataset = TensorDataset(
            torch.from_numpy(data.astype("float32")).to(self.device)
        )
        dataloader = DataLoader(
            dataset, batch_size=self.batch_size, shuffle=True, drop_last=True
        )

        self.generator = Generator(
            self.latent_dim, data.shape[1], binary=self.binary
        ).to(self.device)
        discriminator = Discriminator(data.shape[1]).to(self.device)
        optimizer_d = optim.Adam(discriminator.parameters(), lr=4e-4,
                                 betas = (self.beta1, 0.999)
                                 #betas = (0.5, 0.999)
                                 )

        privacy_engine = PrivacyEngine(
            discriminator,
            batch_size=self.batch_size,
            sample_size=len(data),
            alphas=[1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64)),
            noise_multiplier=3.5,
            max_grad_norm=1.0,
            clip_per_layer=True,
        )

        privacy_engine.attach(optimizer_d)
        optimizer_g = optim.Adam(self.generator.parameters(), lr=1e-4,
                                 betas = (self.beta1, 0.999)
                                 #betas = (0.5, 0.999)
                                 )

        criterion = nn.BCELoss()

        if self.delta is None:
            self.delta = 1 / (data.shape[0] * np.sqrt(data.shape[0]))
        
        # Sanity check of delta value.
        print("Delta: ", self.delta)
        
        # Initializing empty lists for the generator and discriminator loss plots.
        if self.plot_losses:
            discriminator_accuracies = []   # for storing average of discriminator accuracies
            discriminator_losses = []   # for storing average of discriminator losses
            generator_losses = []   # for storing average of generator losses
            
        if self.epoch_time:
            begin_time = time.time()

        for epoch in range(self.epochs):
            eps, best_alpha = optimizer_d.privacy_engine.get_privacy_spent(self.delta)

            if self.epsilon < eps:
                if epoch == 0:
                    raise ValueError(
                        "Inputted epsilon and sigma parameters are too small to"
                        + " create a private dataset. Try increasing either parameter and rerunning."
                    )
                elif self.epoch_time:
                    end_time = time.time()
                    print(f"Average time per epoch: {(end_time - begin_time)/(epoch):.6f} s/epoch")
                else:
                    pass
                break
            
            # Initializing empty lists for the generator and discriminator loss plots.
            if self.plot_losses:
                fake_accs = []   # for storing discriminator's 'fake' accuracies
                real_accs = []   # for storing discriminator's 'real' accuracies
                disc_losses = []   # for storing discriminator losses
                gen_losses = []   # for storing generator losses
                
            for i, data in enumerate(dataloader):
                discriminator.zero_grad()

                real_data = data[0].to(self.device)

                # train with fake data
                noise = torch.randn(
                    self.batch_size, self.latent_dim, 1, 1, device=self.device
                )
                noise = noise.view(-1, self.latent_dim)
                fake_data = self.generator(noise)
                label_fake = torch.full(
                    (self.batch_size,), 0, dtype=torch.float, device=self.device
                )
                output_fake = discriminator(fake_data.detach())
                loss_d_fake = criterion(output_fake.squeeze(), label_fake)
                loss_d_fake.backward()
                optimizer_d.step()

                # train with real data
                label_true = torch.full(
                    (self.batch_size,), 1, dtype=torch.float, device=self.device
                )
                output_real = discriminator(real_data.float())
                loss_d_real = criterion(output_real.squeeze(), label_true)
                loss_d_real.backward()
                optimizer_d.step()
                
                if self.plot_losses:
                    # Computing the accuracy of the discriminator on the
                    # real and fake predictions. 
                    acc_real = (torch.sum(output_real > 0.5) / output_real.shape[0]).item()
                    #print(output_real.shape[0], output_real > 0.5, torch.sum(output_real > 0.5))
                    acc_fake = (torch.sum(output_fake < 0.5) / output_fake.shape[0]).item()
                    #print(output_fake.shape[0], output_fake < 0.5, torch.sum(output_fake < 0.5))
                    # Storing discriminator accuracies.
                    fake_accs.append(acc_fake)   
                    real_accs.append(acc_real)
                    # Storing discriminator losses.
                    disc_losses.append((loss_d_fake + loss_d_real).item())
                
                max_grad_norm = []
                for p in discriminator.parameters():
                    param_norm = p.grad.data.norm(2).item()
                    max_grad_norm.append(param_norm)

                privacy_engine.max_grad_norm = max_grad_norm

                # train generator
                self.generator.zero_grad()
                label_g = torch.full(
                    (self.batch_size,), 1, dtype=torch.float, device=self.device
                )
                output_g = discriminator(fake_data)
                loss_g_disc = criterion(output_g.squeeze(), label_g)

                # Computing the specified fairness loss. 
                if self.fair_loss == "dem":
                    # Demographic parity.
                    loss_g_fair = self.data_fair_loss(data = fake_data, s = self.s,
                                                  s_unpriv = self.s_unpriv,
                                                  s_priv = self.s_priv, y = self.y, 
                                                  y_des = self.y_des, lamda = self.lamda,
                                                  data_loss = "dem", s_labs = s_labs, y_labs = y_labs)
                elif self.fair_loss == "dis":
                    # Disparate impact.
                    loss_g_fair = self.data_fair_loss(data = fake_data, s = self.s,
                                                s_unpriv = self.s_unpriv,
                                                s_priv = self.s_priv, y = self.y, 
                                                y_des = self.y_des, lamda = self.lamda,
                                                data_loss = "dis", s_labs = s_labs, y_labs = y_labs)
                elif self.fair_loss == "dem-dis":
                    # Demographic parity + disparate impact.
                    loss_g_fair = self.data_fair_loss(data = fake_data, s = self.s,
                                                s_unpriv = self.s_unpriv,
                                                s_priv = self.s_priv, y = self.y, 
                                                y_des = self.y_des, lamda = self.lamda,
                                                data_loss = "dem-dis", s_labs = s_labs, y_labs = y_labs)
                elif self.fair_loss == "clf_dem":
                    # Demographic parity based on classifier's predictions.
                    loss_g_fair = self.clf_fair_loss(data = fake_data, s = self.s,
                                             s_unpriv = self.s_unpriv,
                                             s_priv = self.s_priv, y = self.y, 
                                             y_des = self.y_des, lamda = self.lamda,
                                             clf_loss = "dem")
                elif self.fair_loss == "clf_dis":
                    # Disparate impact based on classifier's predictions.
                    loss_g_fair = self.clf_fair_loss(data = fake_data, s = self.s,
                                             s_unpriv = self.s_unpriv,
                                             s_priv = self.s_priv, y = self.y, 
                                             y_des = self.y_des, lamda = self.lamda,
                                             clf_loss = "dis")
                elif self.fair_loss == "clf_eqopp":
                    # Equal opportunity based on classifier's predictions.
                    loss_g_fair = self.clf_fair_loss(data = fake_data, s = self.s,
                                             s_unpriv = self.s_unpriv,
                                             s_priv = self.s_priv, y = self.y, 
                                             y_des = self.y_des, lamda = self.lamda,
                                             clf_loss = "eqopp")
                elif self.fair_loss == "clf_all":
                    # Demographic parity + disparate impact + equal opportunity, based on classifier's predictions.
                    loss_g_fair = self.clf_fair_loss(data = fake_data, s = self.s,
                                             s_unpriv = self.s_unpriv,
                                             s_priv = self.s_priv, y = self.y, 
                                             y_des = self.y_des, lamda = self.lamda,
                                             clf_loss = "clf_all")
                else:
                    raise ValueError("There is no fair loss specified or chosen fair loss is not supported.")
                
                loss_g = loss_g_disc + loss_g_fair
                loss_g.backward()
                optimizer_g.step()
                
                # Storing generator losses.
                if self.plot_losses:
                    gen_losses.append(loss_g.item())

                # manually clear gradients
                for p in discriminator.parameters():
                    if hasattr(p, "grad_sample"):
                        del p.grad_sample
                # autograd_grad_sample.clear_backprops(discriminator)

                if self.delta is None:
                    self.delta = 1 / data.shape[0]
                    
            # Saving averaged discriminator accuracy & loss and generator loss.
            if self.plot_losses:
                discriminator_accuracies.append((np.mean(fake_accs), np.mean(real_accs)))
                discriminator_losses.append(np.mean(disc_losses))
                generator_losses.append(np.mean(gen_losses))
            
        # Plotting generator loss and discriminator accuracy & loss.
        if self.plot_losses:
            
            # Plotting discriminator accuracy and loss during training.
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 10))
            fig.suptitle("Discriminator")
            ax1.set_title("Accuracy During Training")
            ax1.plot(range(len(discriminator_accuracies)), 
                     [discriminator_accuracies[i][0] for i in range(len(discriminator_accuracies))],
                     label = "Fake preds.")
            ax1.plot(range(len(discriminator_accuracies)), 
                     [discriminator_accuracies[i][1] for i in range(len(discriminator_accuracies))], 
                     label = "Real preds.")
            ax1.set_xlabel("Iterations")
            ax1.set_ylabel("Accuracy (%)")
            ax1.legend()
            ax2.set_title("Loss During Training")
            ax2.plot(range(len(discriminator_losses)), discriminator_losses)
            ax2.set_xlabel("Iterations")
            ax2.set_ylabel("Loss")
            if self.file_path:
                plt.savefig(self.file_path + "discriminator_plots.png",
                            dpi=500, bbox_inches='tight', pad_inches=0.1)
            
            # Plotting generator loss during training.  
            fig, ax = plt.subplots(1, 1)
            ax.set_title("Generator Loss During Training")
            ax.plot(range(len(generator_losses)), generator_losses)
            ax.set_xlabel("Iterations")
            ax.set_ylabel("Loss")
            if self.file_path:
                plt.savefig(self.file_path + "generator_plot.png",
                            dpi=500, bbox_inches='tight', pad_inches=0.1)

    def generate(self, n):
        steps = n // self.batch_size + 1
        data = []
        for i in range(steps):
            noise = torch.randn(
                self.batch_size, self.latent_dim, 1, 1, device=self.device
            )
            noise = noise.view(-1, self.latent_dim)

            fake_data = self.generator(noise)
            data.append(fake_data.detach().cpu().numpy())

        data = np.concatenate(data, axis=0)
        data = data[:n]

        return self._transformer.inverse_transform(data)

    def fit(self, data, *ignore, transformer=None, categorical_columns=[], ordinal_columns=[], continuous_columns=[], preprocessor_eps=0.0, nullable=False):
        self.train(data, transformer=transformer, categorical_columns=categorical_columns, ordinal_columns=ordinal_columns, continuous_columns=continuous_columns, preprocessor_eps=preprocessor_eps, nullable=nullable)

    def sample(self, n_samples):
        return self.generate(n_samples)
