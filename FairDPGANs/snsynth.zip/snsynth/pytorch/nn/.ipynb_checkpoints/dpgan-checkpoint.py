import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim

from torch.utils.data import DataLoader, TensorDataset

from opacus import PrivacyEngine

from snsynth.base import Synthesizer

from ._generator import Generator
from ._discriminator import Discriminator

import time


class DPGAN(Synthesizer):
    def __init__(
        self,
        binary=False,
        latent_dim=64,
        batch_size=64,
        epochs=1000,
        delta=None,
        epsilon=1.0,
        plot_losses = False,   # Boolean argument: if True, losses of the generator and discriminator will be plotted
        file_path = None,   # loss plots will be saved at this filepath
        epoch_time = False   # Boolean argument: if True, average time per epoch will be returned
    ):
        self.binary = binary
        self.latent_dim = latent_dim
        self.batch_size = batch_size
        self.epochs = epochs
        self.delta = delta
        self.epsilon = epsilon
        self.plot_losses = plot_losses
        self.file_path = file_path
        self.epoch_time = epoch_time

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

        self.pd_cols = None
        self.pd_index = None

    def train(
        self,
        data,
        categorical_columns=None,
        ordinal_columns=None,
        update_epsilon=None,
        transformer=None,
        continuous_columns=None,
        preprocessor_eps=0.0,
        nullable=False,
    ):
        if update_epsilon:
            self.epsilon = update_epsilon

        train_data = self._get_train_data(
            data,
            style='gan',
            transformer=transformer,
            categorical_columns=categorical_columns, 
            ordinal_columns=ordinal_columns, 
            continuous_columns=continuous_columns, 
            nullable=nullable,
            preprocessor_eps=preprocessor_eps
        )

        data = np.array(train_data)
        print("data.shape:", data.shape)

        if isinstance(data, pd.DataFrame):
            for col in data.columns:
                data[col] = pd.to_numeric(data[col], errors="ignore")
            self.pd_cols = data.columns
            self.pd_index = data.index
            data = data.to_numpy()
        elif isinstance(data, list):
            data = np.array(data)
        elif not isinstance(data, np.ndarray):
            raise ValueError("Data must be a numpy array or pandas dataframe")

        dataset = TensorDataset(
            torch.from_numpy(data.astype("float32")).to(self.device)
        )
        dataloader = DataLoader(
            dataset, batch_size=self.batch_size, shuffle=True, drop_last=True
        )

        self.generator = Generator(
            self.latent_dim, data.shape[1], binary=self.binary
        ).to(self.device)
        discriminator = Discriminator(data.shape[1]).to(self.device)
        optimizer_d = optim.Adam(discriminator.parameters(), lr=4e-4)

        privacy_engine = PrivacyEngine(
            discriminator,
            batch_size=self.batch_size,
            sample_size=len(data),
            alphas=[1 + x / 10.0 for x in range(1, 100)] + list(range(12, 64)),
            noise_multiplier=3.5,
            max_grad_norm=1.0,
            clip_per_layer=True,
        )

        privacy_engine.attach(optimizer_d)
        optimizer_g = optim.Adam(self.generator.parameters(), lr=1e-4)

        criterion = nn.BCELoss()

        if self.delta is None:
            self.delta = 1 / (data.shape[0] * np.sqrt(data.shape[0]))
        
        # Sanity check of delta value.
        print("Delta: ", self.delta)
        
        # Initializing empty lists for the generator and discriminator loss plots.
        if self.plot_losses:
            discriminator_accuracies = []   # for storing average of discriminator accuracies
            discriminator_losses = []   # for storing average of discriminator losses
            generator_losses = []   # for storing average of generator losses

        if self.epoch_time:
            begin_time = time.time()
            
        for epoch in range(self.epochs):
            eps, best_alpha = optimizer_d.privacy_engine.get_privacy_spent(self.delta)

            if self.epsilon < eps:
                if epoch == 0:
                    raise ValueError(
                        "Inputted epsilon and sigma parameters are too small to"
                        + " create a private dataset. Try increasing either parameter and rerunning."
                    )
                elif self.epoch_time:
                    end_time = time.time()
                    print(f"Average time per epoch: {(end_time - begin_time)/(epoch):.6f} s/epoch")
                    print(f"Number of epochs: {epoch} epochs")
                else:
                    pass
                break
            
            # Initializing empty lists for the generator and discriminator loss plots.
            if self.plot_losses:
                fake_accs = []   # for storing discriminator's 'fake' accuracies
                real_accs = []   # for storing discriminator's 'real' accuracies
                disc_losses = []   # for storing discriminator losses
                gen_losses = []   # for storing generator losses
            
            for i, data in enumerate(dataloader):
                discriminator.zero_grad()

                real_data = data[0].to(self.device)

                # train with fake data
                noise = torch.randn(
                    self.batch_size, self.latent_dim, 1, 1, device=self.device
                )
                noise = noise.view(-1, self.latent_dim)
                fake_data = self.generator(noise)
                label_fake = torch.full(
                    (self.batch_size,), 0, dtype=torch.float, device=self.device
                )
                output_fake = discriminator(fake_data.detach())
                loss_d_fake = criterion(output_fake.squeeze(), label_fake)
                loss_d_fake.backward()
                optimizer_d.step()

                # train with real data
                label_true = torch.full(
                    (self.batch_size,), 1, dtype=torch.float, device=self.device
                )
                output_real = discriminator(real_data.float())
                loss_d_real = criterion(output_real.squeeze(), label_true)
                loss_d_real.backward()
                optimizer_d.step()
                
                if self.plot_losses:
                    # Computing the accuracy of the discriminator on the
                    # real and fake predictions. 
                    acc_real = (torch.sum(output_real > 0.5) / output_real.shape[0]).item()
                    #print(output_real.shape[0], output_real > 0.5, torch.sum(output_real > 0.5))
                    acc_fake = (torch.sum(output_fake < 0.5) / output_fake.shape[0]).item()
                    #print(output_fake.shape[0], output_fake < 0.5, torch.sum(output_fake < 0.5))
                    # Storing discriminator accuracies.
                    fake_accs.append(acc_fake)   
                    real_accs.append(acc_real)
                    # Storing discriminator losses.
                    disc_losses.append((loss_d_fake + loss_d_real).item())
                
                max_grad_norm = []
                for p in discriminator.parameters():
                    param_norm = p.grad.data.norm(2).item()
                    max_grad_norm.append(param_norm)

                privacy_engine.max_grad_norm = max_grad_norm

                # train generator
                self.generator.zero_grad()
                label_g = torch.full(
                    (self.batch_size,), 1, dtype=torch.float, device=self.device
                )
                output_g = discriminator(fake_data)
                loss_g = criterion(output_g.squeeze(), label_g)
                loss_g.backward()
                optimizer_g.step()
                
                # Storing generator losses.
                if self.plot_losses:
                    gen_losses.append(loss_g.item())

                # manually clear gradients
                for p in discriminator.parameters():
                    if hasattr(p, "grad_sample"):
                        del p.grad_sample
                # autograd_grad_sample.clear_backprops(discriminator)

                if self.delta is None:
                    self.delta = 1 / data.shape[0]
            
            # Saving averaged discriminator accuracy & loss and generator loss.
            if self.plot_losses:
                discriminator_accuracies.append((np.mean(fake_accs), np.mean(real_accs)))
                discriminator_losses.append(np.mean(disc_losses))
                generator_losses.append(np.mean(gen_losses))
            
            
        # Plotting generator loss and discriminator accuracy & loss.
        if self.plot_losses:
            
            # Plotting discriminator accuracy and loss during training.
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 10))
            fig.suptitle("Discriminator")
            ax1.set_title("Accuracy During Training")
            ax1.plot(range(len(discriminator_accuracies)), 
                     [discriminator_accuracies[i][0] for i in range(len(discriminator_accuracies))],
                     label = "Fake preds.")
            ax1.plot(range(len(discriminator_accuracies)), 
                     [discriminator_accuracies[i][1] for i in range(len(discriminator_accuracies))], 
                     label = "Real preds.")
            ax1.set_xlabel("Iterations")
            ax1.set_ylabel("Accuracy (%)")
            ax1.legend()
            ax2.set_title("Loss During Training")
            ax2.plot(range(len(discriminator_losses)), discriminator_losses)
            ax2.set_xlabel("Iterations")
            ax2.set_ylabel("Loss")
            if self.file_path:
                plt.savefig(self.file_path + "discriminator_plots.png",
                            dpi=500, bbox_inches='tight', pad_inches=0.1)
            
            # Plotting generator loss during training. 
            fig, ax = plt.subplots(1, 1)
            ax.set_title("Generator Loss During Training")
            ax.plot(range(len(generator_losses)), generator_losses)
            ax.set_xlabel("Iterations")
            ax.set_ylabel("Loss")
            if self.file_path:
                plt.savefig(self.file_path + "generator_plot.png",
                            dpi=500, bbox_inches='tight', pad_inches=0.1)

    def generate(self, n):
        steps = n // self.batch_size + 1
        data = []
        for i in range(steps):
            noise = torch.randn(
                self.batch_size, self.latent_dim, 1, 1, device=self.device
            )
            noise = noise.view(-1, self.latent_dim)

            fake_data = self.generator(noise)
            data.append(fake_data.detach().cpu().numpy())

        data = np.concatenate(data, axis=0)
        data = data[:n]

        return self._transformer.inverse_transform(data)

    def fit(self, data, *ignore, transformer=None, categorical_columns=[], ordinal_columns=[], continuous_columns=[], preprocessor_eps=0.0, nullable=False):
        self.train(data, transformer=transformer, categorical_columns=categorical_columns, ordinal_columns=ordinal_columns, continuous_columns=continuous_columns, preprocessor_eps=preprocessor_eps, nullable=nullable)

    def sample(self, n_samples):
        return self.generate(n_samples)
